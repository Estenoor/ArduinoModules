This is an Arduino library for WS2801 LED pixels

Pick some up at http://www.adafruit.com/products/322

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder WS2801. Check that the WS2801 folder contains WS2801.cpp and WS2801.h

Place the WS2801 library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.